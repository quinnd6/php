<?php $__env->startSection('title'); ?>
Create New Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php echo Form::open(['route' => 'product.store']); ?>

    
    <?php echo Form::label('name', 'Name'); ?>

    <?php echo Form::text('name', null, ['placeholder' => 'Give a name']); ?>

    
    <br>
    
    <?php echo Form::label('price', 'Price'); ?>

    <?php echo Form::text('price', '0$', ['placeholder' => 'Give a price']); ?>

    
    <?php echo Form::submit('Create'); ?>

    
    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>