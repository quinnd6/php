<?php $__env->startSection('tile'); ?>
	All products
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
	<?php foreach($products as $product): ?>
		<h1><?php echo e($product->name); ?></h1>
		<h3><?php echo e($product->price); ?></h3>
		<br>
	<?php endforeach; ?>
        
        <a href="<?php echo e(url('basicrouting')); ?>">Basic routing</a>
        <a href="<?php echo e(route('about')); ?>">About</a>
        <a href="<?php echo e(route('product.create')); ?>">Create</a>
        
        <a href="<?php echo e(route('test', ['id' => 15])); ?>">Test</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>