<?php $__env->startSection('title'); ?> 
About 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
	<h1>This is the about page.</h1>
	
	<p><?php echo e($companyName); ?></p>
	
	<?php if($isUserRegistered == true): ?>
		<p>Hello mate!</p>
	<?php else: ?>
		<p>Please Register!</p>
	<?php endif; ?>
	
	<?php for($i = 0; $i < 10; $i++): ?>
    <p>The current value is <?php echo e($i); ?></p>
	<?php endfor; ?>
	
	<?php foreach($users as $data): ?>
		<?php echo e($data); ?><br>
	<?php endforeach; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>