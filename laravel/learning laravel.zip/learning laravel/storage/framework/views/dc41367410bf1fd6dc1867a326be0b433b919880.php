<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <a href="<?php echo e(route('admin::dashboard')); ?>">Dashboard</a>
                <a href="<?php echo e(route('admin::reports')); ?>">Reports</a>
            </div>
        </div>
    </body>
</html>
