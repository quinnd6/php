<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <a href="{{route('admin::dashboard')}}">Dashboard</a>
                <a href="{{route('admin::reports')}}">Reports</a>
            </div>
        </div>
    </body>
</html>
