<!DOCTYPE html>
<html>
<head>
	<title>@yield('title')</title>
</head>
<body>
	@include('layouts.menu')
	@yield('body')
</body>
</html>