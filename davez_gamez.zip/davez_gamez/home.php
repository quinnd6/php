<div id="content">
    <div id ="searchbar">
        <form action="searchresults.php" method="get">
        <input type="text" name="gameSearchName">
        <input type="submit" value="search">
        </form> 
    </div>
<div id="page_title"><h2> Home </h2></div>
<div id="boxed_item">
<p>Welcome to Davez Gamez.<br/> 
We sell all types of video games and consoles and some other things aswell. <br/>
Please take a look at our 
<a href="games">Games</a>, <a href="consoles">Consoles</a> , <a href="accessories">Accessories</a> and <a href="other">Other</a> pages to see what we have in stock.
<p>
    I also sell games and consoles on behalf of people who can't do so. 
Time to look in the attics and under the beds for those old consoles and games.<br/>
 If anyone needs anything sold just send me a message or post to the wall. 
Only a small percentage will be charged should your item sell.<br />
My facebook page link can be found on the contact us page.
</p>
</div>
</div>