<?php 
require "connect_to_mysql.php";  

echo "<h1>Success in database connection! Happy Coding!</h1>";   
// if no success the script would have died before this success message 
?>