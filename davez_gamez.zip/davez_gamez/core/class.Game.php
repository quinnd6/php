<?php
class Game {
  public $name;
  public $description;
  public $price;
  public $picurl1;
  
}
?>