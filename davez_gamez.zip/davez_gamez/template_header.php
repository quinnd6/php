<div id="pageHeader">
                <table width="100%" border="0" cellspacing="0" cellpadding="12"> 
                    <tr>
                        <td width="32%"><a href="http://localhost/davez_gamez/storeadmin/"><img src="http://localhost/MyOnlineStore/style/logo.jpg" alt="Logo" width="252" height="36" border="0"/></a> </td>
                        
                    </tr>
                    <tr>
                        <td colspan="2"><a href="http://localhost/davez_gamez/storeadmin/">Home</a>&nbsp;&middot;&nbsp;<a href="#">Contact</a></td>
                    </tr>
                </table>
 </div>