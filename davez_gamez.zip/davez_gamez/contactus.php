
<div id="content">
<div id="page_title"><h2>Contact Us</h2></div>
<div id ="boxed_item">You can contact me on facebook or twitter to find out how to buy and to find out more
about all the products on our website.<br/>
<a href="https://www.facebook.com/DavezGamez" target="_blank"><img src="images/FB_FindUsOnFacebook-100.png"></a></div>
</div>
