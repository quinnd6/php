<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
	<link rel="stylesheet" href="css/style.css" type="text/css" />
	
</head>
<body>
    <div id="wrapper">
    
    <div id="header" title="DAVEZ GAMEZ">
        <a href="."></a>
         
    </div>
        
       <div id="cart">
            <a href="cart.php">My Cart</a>
        </div>
    