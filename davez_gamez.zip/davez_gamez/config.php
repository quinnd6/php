<?php
    //Database Config File
    
    define('DB_NAME' , 'davez_gamez');
    define('DB_HOST' , 'localhost');
    define('DB_USER' , 'root');
    define('DB_PASSWORD' , 'password');
?>